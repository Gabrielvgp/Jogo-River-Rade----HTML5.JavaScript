/*Gabriel Vicente Guerra Pereira
	Laureson Ribeiro da Cruz
	Augusto de Souza*/

var	vertexShaderSource,
fragmentShaderSource,
vertexShader,
fragmentShader,
shaderProgram,
positionAttr,
luzUniform,
luz,
canvas,
gl,
buffer,
buffer2,
data,
normalAttr,
cor,
corUniform,
dx=0.5,dx2=3,dx3=-5,dx4 = 7,
xi=-Math.random() * (-5 - (-3)) + (-3),
zi=-Math.random() * (-5 - (-3)) + (-3),
ponto= 0,
di=Math.random() * (-7- (-7)) + (-7),
i=0,
aux=0,
e=-Math.random() * (-100 - (-400)) + (-400),
e2=-Math.random() * (-100 - (-400)) + (-400),
e3=-Math.random() * (-100 - (-400)) + (-400),
e4=-Math.random() * (-100 - (-400)) + (-400),
ei =-Math.random() * (-250 - (-400)) + (-400),
min = -10,max = 10,
cx = 0,cy = 3,cz = 1.3,
ep=0,
px=i,
ep2=0,
px2=i,
vy = -2,vz= -10,vx=0,
vida = 0.8,

camera;

/* MATRIZES */
var projection,
projectionUniform,
view,
viewUniform,
model,
modelUniform;


//Sistema de arquivos
window.addEventListener("SHADERS_LOADED", main);
loadFile("vertex.glsl","VERTEX",loadShader);
loadFile("fragment.glsl","FRAGMENT",loadShader);
function loadFile(filename, type, callback){
	var xhr = new XMLHttpRequest();
	xhr.open("GET",filename,true);
	xhr.onload = function(){callback(xhr.responseText,type)};
	xhr.send();
}

function getGLContext(){
	canvas = document.getElementById("canvas");
	gl = canvas.getContext("webgl") || canvas.getContext("experimental-webgl");
	//gl.viewport(0, 0, canvas.width, canvas.height);
	gl.enable(gl.DEPTH_TEST);
}

function loadShader(text,type){
	if(type == "VERTEX") vertexShaderSource = text;
	if(type == "FRAGMENT") fragmentShaderSource = text;
	if(vertexShaderSource && fragmentShaderSource) window.dispatchEvent(new Event("SHADERS_LOADED"));
}

function compileShader(source,type){
	shader = gl.createShader(type);
	gl.shaderSource(shader, source);
	gl.compileShader(shader);
	if (!gl.getShaderParameter(shader, gl.COMPILE_STATUS)) console.log(gl.getShaderInfoLog(shader));
	return shader;
}

function linkProgram(vertexShader,fragmentShader){
	var program	= gl.createProgram();
	gl.attachShader(program, vertexShader);
	gl.attachShader(program, fragmentShader);
	gl.linkProgram(program);
	if (!gl.getProgramParameter(program, gl.LINK_STATUS)) console.log("Error: Program Linking.");
	return program;
}

function getData(){
	var p = [
		[-1,1,-1],
		[1,1,-1],
		[1,1,1],
		[-1,1,1],
		[-1,-1,-1],
		[1,-1,-1],
		[1,-1,1],
		[-1,-1,1]
	];

	var barraV = [
		- 0,9 , - 0,9 ,
		0,9 , - 0,9 ,
		- 0,0 ,   0,9
	];


	var dN = [
		[0,1,0],
		[-1,0,0],
		[0,0,-1],
		[1,0,0],
		[0,-1,0],
		[0,0,1]
	];
	var normal = [

		//cima
		dN[0],dN[0],dN[0],
		dN[0],dN[0],dN[0],
		//esquerda
		dN[1],dN[1],dN[1],
		dN[1],dN[1],dN[1],
		//traz
		dN[2],dN[2],dN[2],
		dN[2],dN[2],dN[5],
		//direita
		dN[3],dN[3],dN[3],
		dN[3],dN[3],dN[3],
		// baixo
		dN[4],dN[4],dN[4],
		dN[4],dN[4],dN[4],
		//frente
		dN[5],dN[4],dN[5],
		dN[5],dN[5],dN[5]
	];


	var faces = [
		//cima
		p[0],p[2],p[1],
		p[0],p[3],p[2],
		//esquerda
		p[0],p[3],p[4],
		p[3],p[4],p[7],
		//traz
		p[0],p[1],p[4],
		p[1],p[4],p[5],
		//direita
		p[1],p[2],p[5],
		p[2],p[5],p[6],
		// baixo
		p[4],p[6],p[5],
		p[4],p[6],p[7],
		//frente
		p[2],p[3],p[6],
		p[3],p[6],p[7]
	];

	//points = faces	.map(a => a - .5);


	return {"faces": new Float32Array(flatten(faces)),
	"normal": new Float32Array(flatten(normal)),
	"barraVida": new Float32Array(flatten(barraV))
};


}








function flatten(nested){
	var flat = [];
	for(var i=0; i < nested.length; i++){
		flat = flat.concat(nested[i]);
	}
	return flat;
}

function main() {
	/* LOAD GL */
	getGLContext();


	/* COMPILE AND LINK */
	vertexShader = compileShader(vertexShaderSource, gl.VERTEX_SHADER);
	fragmentShader = compileShader(fragmentShaderSource, gl.FRAGMENT_SHADER);
	shaderProgram = linkProgram(vertexShader,fragmentShader);
	gl.useProgram(shaderProgram);

	/* PARAMETERS */
	data = getData();
	positionAttr = gl.getAttribLocation(shaderProgram, "position");
	buffer = gl.createBuffer();
	gl.bindBuffer(gl.ARRAY_BUFFER, buffer);
	gl.bufferData(gl.ARRAY_BUFFER, data.faces, gl.STATIC_DRAW);
	gl.enableVertexAttribArray(positionAttr);
	gl.vertexAttribPointer(positionAttr, 3, gl.FLOAT, false, 0, 0);



	normalAttr = gl.getAttribLocation(shaderProgram, "normal");
	buffer2 = gl.createBuffer();
	gl.bindBuffer(gl.ARRAY_BUFFER, buffer2);
	gl.bufferData(gl.ARRAY_BUFFER, data.normal, gl.STATIC_DRAW);
	gl.enableVertexAttribArray(normalAttr);
	gl.vertexAttribPointer(normalAttr, 3, gl.FLOAT, false, 0, 0);
	/* UNIFORM */
	luzUniform = gl.getUniformLocation(shaderProgram,"luz");
	luz = new Float32Array([0.0,25.0,-35]);
	gl.uniform3fv(luzUniform, luz);


	corUniform = gl.getUniformLocation(shaderProgram,"cor");
	red = new Float32Array([0.6,0.0,0.0]);
	blue = new Float32Array([0.3,0.4,1.0]);
	white = new Float32Array([1.0,1.0,1.0]);
	black = new Float32Array([0.0,0.0,0.0]);
	green = new Float32Array([0.0,0.5,0.0]);
	marrom = new Float32Array([0.0,1.0,1.0]);





	projectionUniform = gl.getUniformLocation(shaderProgram,"projection");

	viewUniform = gl.getUniformLocation(shaderProgram,"view");

	modelUniform = gl.getUniformLocation(shaderProgram,"model");


	projection = mat4.perspective([],Math.PI/4, window.innerWidth/window.innerHeight, 0.1, 1000);




	modelParede = [
		1,0,0,0,
		0,1,0,0,
		0,0,500,0,
		10,-2,-299,1
	];

	modelChao = [
		11,0,0,0,
		0,1,0,0,
		0,0,500,0,
		0,-3,-299,1
	];


	modelParede2 = [
		1,0,0,0,
		0,1,0,0,
		0,0,500,0,
		-10,-2,-299,1
	];



	gl.uniformMatrix4fv(projectionUniform,gl.FALSE,new Float32Array(projection));

	gl.uniformMatrix4fv(viewUniform,gl.FALSE,new Float32Array(view));

	gl.uniformMatrix4fv(modelUniform,gl.FALSE,new Float32Array(model));


	/* DRAW */
	//gl.lineWidth(5.0);
	//gl.POINTS, gl.LINES, gl.LINE_STRIP, gl.LINE_LOOP, gl.TRIANGLES

	resize();

	animate();



}



function drawScore() {

	document.write("Pontos: "+ponto);}


	document.addEventListener("keydown", onkeydown, false);
	function onkeydown(event) {
		var keyCode = event.which;

		// direta
		if (keyCode == 39 &&  i< 7.4) {


			i+=0.4;
			cx+=0.4;

		}
		// esquerda

		else if (keyCode == 37 &&  i>-7.4) {
			i-=0.4;
			cx-=0.4;


		}
		if (keyCode == 50  ) {
			if (cx <=20  ) {

				cx +=0.1;}
				if (cy <=10  ) {
					cy +=0.1;}
					if (cz <=10  ) {
						cz += 0.1;}
					}

					if (keyCode == 49 ) {
						cx = i; cy = 3; cz =1.3;

					}
				}





				document.addEventListener("keyup", onkeyup, false);
				function onkeyup(event) {
					var keyCodes = event.which;

					if (keyCodes == 69  ||keyCodes == 32   ) {
						ep-=0.02;

						if (ep>=-1) {


							aux = i;
							px = aux;
						}}
						if (keyCodes ==81   || keyCodes == 32 ) {
							ep2-=0.02;

							if (ep2>=-1) {


								aux = i;
								px2 = aux;
							}

						}
						if (ep<=-15){

							px=i;
						}




						if (ep2<=-15){

							px2=i;
						}


					}







					// animate
					function animate(event){
						document.getElementById("RR").innerHTML="Pontos: "+ponto;
						if (ei < 3){
							ei+=1.5;
						}
						else{
							ei=Math.random() * (-250 - (-400)) + (-400);
							di=Math.random() * (8 - (-8)) + (-8);
							xi=-Math.random() * (-5 - (-3)) + (-3);
							zi=-Math.random() * (-5 - (-3)) + (-3);
						}
						if(vida <=0){
							vida= 0;
							e2-=0;
							e3-=0;
							e4-=0;
							e-=0;

							alert("Voce Perdeu. Sua pontuacao foi de: " +ponto)

							document.location.reload();
						}
						if (e4 <= 0){
							e4-=-1.3;
						}
						else {
							e4 = Math.random() * (-100 - (-400)) + (-400);
							dx4=Math.random() * (8 - (-8)) + (-8);

						}

						if (ep>=0.0){
							px  = i;
						}
						else {
							px=aux;
						}

						if (ep2>=0.0){
							px2  = i;
						}
						else {
							px2=aux;
						}

						camera = [cx,cy,cz];
						view = mat4.lookAt([],camera,[0,vy,vz],[0,1,0]);
						gl.uniformMatrix4fv(viewUniform,gl.FALSE,new Float32Array(view));




						if (e < 3){
							e+=1.5;}
							else {
								e= Math.random() * (-100 - (-400)) + (-400);
								dx=Math.random() * (8 - (-8)) + (-8);
							}




							if (e2 < 3){
								e2+=1.5;
							}

							else {
								e2= Math.random() * (-100 - (-400)) + (-400);
								dx2=Math.random() * (8 - (-8)) + (-8);

							}
							if (e3 < 3){
								e3+=1.5;
							}

							else {
								e3= Math.random() * (-100 - (-400)) + (-400);
								dx3=Math.random() * (8 - (-8)) + (-8);

							}




							model = [
								1,0,0,0,
								0,1,0,0,
								0,0,1,0,
								i,0,0,1
							];

							if (dx <= i+2 && dx >= i-2  && e >=-2  && e <=0){
								e =  Math.random() * (-100 - (-400)) + (-400);
								dx=Math.random() * (8 - (-8)) + (-8);
								vida = vida -0.3;
							}






							if (dx3 <= i+2 && dx3 >= i-2  && e3 >=-2  && e3 <=0){
								e3 =  Math.random() * (-100 - (-400)) + (-400);
								dx3=Math.random() * (8 - (-8)) + (-8);
								vida = vida -0.3;
							}

							if (dx4 <= i+2 && dx4 >= i-2  && e4 >=-2  && e4 <=0){
								e4 =  Math.random() * (-100 - (-400)) + (-400);

								dx4=Math.random() * (8 - (-8)) + (-8);
								if (vida < 0.8){
									aux =( 0.8 -vida) /2;
									vida = vida +aux;
								}
							}



							if (dx2 <= i+2 && dx2 >= i-2 && e2 >=-2  && e2 <=0 ){
								dx2=Math.random() * (8 - (-8)) + (-8);

								e2 =  Math.random() * (-100 - (-400)) + (-400);
								vida = vida -0.3;
							}

							if (di <= i+1- xi && di >= i-1+xi && ei >=-3.5 && ei<=0 ){

								vida -= vida ;
							}

							//colisão modelProjetil
							if (ep < 0){
								ep -=2;
							}
							if (ep<=-150){
								px=i;
								ep=0;}

								if (ep2 < 0){
									ep2 -=2;
								}
								if (ep2<=-150){
									px2=i;
									ep2=0;}

									if (dx <= px2+2 && dx >= px2-2  && e >=ep2-2 && e <=ep2+2){
										e =  Math.random() * (-100 - (-400)) + (-400);ep2=0;ponto+=10;
										dx=Math.random() * (8 - (-8)) + (-8);
									}

									if (dx3 <= px2+2 && dx3 >= px2-2  && e3 >=ep2-2 && e3 <=ep2+2){
										e3 = Math.random() * (-100 - (-400)) + (-400);ep2=0;ponto+=10;
										dx3=Math.random() * (8 - (-8)) + (-8);
									}
									if (dx2 <= px2+2 && dx2 >= px2-2  && e2 >=ep2-2 && e2 <=ep2+2){
										e2=  Math.random() * (-100 - (-400)) + (-400);ep2=0;ponto+=10;
										dx2=Math.random() * (8 - (-8)) + (-8);
									}

									if (dx4 <= px2+2 && dx4 >= px2-2  && e4>=ep2-2 && e4 <=ep2+2){
										e4= Math.random() * (-100 - (-400)) + (-400);ep2=0;ponto+=10;
										dx4=Math.random() * (8 - (-8)) + (-8);
									}

									if (dx <= px+2 && dx >= px-2  && e >=ep-2 && e <=ep+2){
										e =  Math.random() * (-100 - (-400)) + (-400);ep=0;ponto+=10;
										dx=Math.random() * (8 - (-8)) + (-8);
									}

									if (dx4 <= px+2 && dx4 >= px-2  && e4>=ep-2 && e4 <=ep+2){
										e4 = Math.random() * (-100 - (-400)) + (-400);ep=0;ponto+=10;
										dx4=Math.random() * (8 - (-8)) + (-8);
									}

									if (dx3 <= px+2 && dx3 >= px-2  && e3 >=ep-2 && e3 <=ep+2){
										e3 =  Math.random() * (-100 - (-400)) + (-400);ep=0;ponto+=10;
										dx3=Math.random() * (8 - (-8)) + (-8);
									}
									if (dx2 <= px+2 && dx2 >= px-2  && e2 >=ep-2 && e2 <=ep+2){
										e2=  Math.random() * (-100 - (-400)) + (-400);ep=0;
										ponto+=10;
										dx2=Math.random() * (8 - (-8)) + (-8);
									}

									modelInimigo = [
										1,0,0,0,
										0,1,0,0,
										0,0,1,0,
										dx,0,e,1
									];
									modelInimigo2 = [
										1,0,0,0,
										0,1,0,0,
										0,0,1,0,
										dx2,0,e2,1
									];

									modelInimigo3 = [
										1,0,0,0,
										0,1,0,0,
										0,0,1,0,
										dx3,0,e3,1
									];

									modelProjetil = [
										0.5,0,0,0,
										0,0.5,0,0,
										0,0,0.8,0,
										px+1,0,ep,1
									];
									modelIlha = [
										xi,0,0,0,
										0,3,0,0,
										0,0,zi,0,
										di,-2,ei,1
									];

									modelProjetil2 = [
										0.5,0,0,0,
										0,0.5,0,0,
										0,0,0.8,0,
										px2-1,0,ep2,1
									];
									if (vida > 0){
										vida-=0.0007;
									}
									modelVida = [
										vida,0,0,0,
										0,0.1,0,0,
										0,0,0.2,0,
										i,1,-0.7,1
									];

									modelAddGas = [
										1,0,0,0,
										0,1,0,0,
										0,0,1,0,
										dx4,0,e4,1
									];

									fundo = [
										101,0,0,0,
										0,100,0,0,
										0,0,100,0,
										0,0,-50,1
									];
									gl.clear( gl.COLOR_BUFFER_BIT | gl.DEPTH_BUFFER_BIT );


									gl.uniform3fv(corUniform, white);
									gl.uniformMatrix4fv(modelUniform,gl.FALSE,new Float32Array(model));
									gl.drawArrays(gl.TRIANGLES, 0, data.faces.length/3);



									gl.uniform3fv(corUniform, green);
									gl.uniformMatrix4fv(modelUniform,gl.FALSE,new Float32Array(modelVida));
									gl.drawArrays(gl.TRIANGLES, 0, data.faces.length/3);

									gl.uniform3fv(corUniform, green);
									gl.uniformMatrix4fv(modelUniform,gl.FALSE,new Float32Array(modelAddGas));
									gl.drawArrays(gl.TRIANGLES, 0, data.faces.length/3);

									gl.uniform3fv(corUniform, white);
									gl.uniformMatrix4fv(modelUniform,gl.FALSE,new Float32Array(modelProjetil));
									gl.drawArrays(gl.TRIANGLES, 0, data.faces.length/3);

									gl.uniform3fv(corUniform, white);
									gl.uniformMatrix4fv(modelUniform,gl.FALSE,new Float32Array(modelProjetil2));
									gl.drawArrays(gl.TRIANGLES, 0, data.faces.length/3);


									gl.uniform3fv(corUniform,blue);
									gl.uniformMatrix4fv(modelUniform,gl.FALSE,new Float32Array(modelChao));
									gl.drawArrays(gl.TRIANGLES, 0, data.faces.length/3);
									gl.uniform3fv(corUniform, marrom);
									gl.uniformMatrix4fv(modelUniform,gl.FALSE,new Float32Array(modelIlha));
									gl.drawArrays(gl.TRIANGLES, 0, data.faces.length/3);

									gl.uniform3fv(corUniform, black);
									gl.uniformMatrix4fv(modelUniform,gl.FALSE,new Float32Array(modelInimigo));
									gl.drawArrays(gl.TRIANGLES, 0, data.faces.length/3);

									gl.uniform3fv(corUniform, black);
									gl.uniformMatrix4fv(modelUniform,gl.FALSE,new Float32Array(modelInimigo2));
									gl.drawArrays(gl.TRIANGLES, 0, data.faces.length/3);

									gl.uniform3fv(corUniform, black);
									gl.uniformMatrix4fv(modelUniform,gl.FALSE,new Float32Array(modelInimigo3));
									gl.drawArrays(gl.TRIANGLES, 0, data.faces.length/3);




									gl.uniform3fv(corUniform, marrom);
									gl.uniformMatrix4fv(modelUniform,gl.FALSE,new Float32Array(modelParede));
									gl.drawArrays(gl.TRIANGLES, 0, data.faces.length/3);

									gl.uniform3fv(corUniform, marrom);
									gl.uniformMatrix4fv(modelUniform,gl.FALSE,new Float32Array(modelParede2));
									gl.drawArrays(gl.TRIANGLES, 0, data.faces.length/3);






									window.requestAnimationFrame(animate);
								}

								function resize(){
									var w  = window.innerWidth;
									var h  = window.innerHeight;
									aspecto = w/h;
									//gl.uniformMatrix4fv
									projection = mat4.perspective([],45, aspecto, 0.1, 1000);

									gl.uniformMatrix4fv(projectionUniform,gl.FALSE,new Float32Array(projection));
									canvas.setAttribute("width",w);
									canvas.setAttribute("height",h);
									gl.viewport(0, 0, w, h);
								}


								/*	function moveCamera(evt){
								var y = (evt.y / window.innerHeight) * 20 -10;
								var x = (evt.x / window.innerWidth) * 20 -10;
								camera = [x,-y,10];
								view = mat4.lookAt([],camera,[0,0,0],[0,1,0]);

								//camera = [x,-y,0];
								//view = mat4.lookAt([],[0,0,10],camera,[0,1,0]);

								gl.uniformMatrix4fv(viewUniform,gl.FALSE,new Float32Array(view));
							}*/

							window.addEventListener("resize",resize);

							//window.addEventListener("mousemove",moveCamera);
