ALUNOS: Gabriel Vicente Guerra Pereira;
	Laureson Ribeiro da Cruz; Augusto de Souza;

JOGO:River Raid

-------------------------------------------------------
MEC�NICA DE JOGO:

	Movimenta��o : Seta direita(key right) e esquerda( key left) .
	Tiros: "Q" atira projetil da esquerda, "E" atira projetil da direita, "Espa�o" atira os dois projeteis.
  	Mantenha pressionada a tecla "2" para animar e ajustar a camera em um angulo diferente, caso goste de um angulo basta soltar o bot�o e a camera  master� a vis�o 
preferida.
	Caso camera n�o esteja em 1� pessoa pressione "1" para voltar a perspectiva.


------------------------------------------------------
INIMIGOS:
	Objetos da cor preta s�o inimigos que podem ser destru�dos  com projete�s,  mata-los lhe conceder� pontos.
	Objetos da cor azul  claro repretam ilhas no qual voc� n�o consegue atravessar e n�o s�o destruidos por tiros.

-----------------------------------------------------
PONTUA��O � MOSTRADA NO CANTO SUPERIOR ESQUERDO DA TELA.
